package com.example.aiagent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AiItOperationsAgentApplicationTests {

	@Test
	void contextLoads() {
	}

}
