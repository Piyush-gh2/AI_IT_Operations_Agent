package com.example.aiagent.dto;

import java.util.List;

public class AgentResponse {

    private String status;
    private String severity;
    private String rootCause;
    private String recommendation;

    private List<String> actionsPerformed;
    private List<String> findings;

    private double confidence;

    public AgentResponse() {
    }

    public AgentResponse(
            String status,
            String severity,
            String rootCause,
            String recommendation,
            List<String> actionsPerformed,
            List<String> findings,
            double confidence) {

        this.status = status;
        this.severity = severity;
        this.rootCause = rootCause;
        this.recommendation = recommendation;
        this.actionsPerformed = actionsPerformed;
        this.findings = findings;
        this.confidence = confidence;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getSeverity() {
        return severity;
    }

    public void setSeverity(String severity) {
        this.severity = severity;
    }

    public String getRootCause() {
        return rootCause;
    }

    public void setRootCause(String rootCause) {
        this.rootCause = rootCause;
    }

    public String getRecommendation() {
        return recommendation;
    }

    public void setRecommendation(String recommendation) {
        this.recommendation = recommendation;
    }

    public List<String> getActionsPerformed() {
        return actionsPerformed;
    }

    public void setActionsPerformed(
            List<String> actionsPerformed) {

        this.actionsPerformed = actionsPerformed;
    }

    public List<String> getFindings() {
        return findings;
    }

    public void setFindings(List<String> findings) {
        this.findings = findings;
    }

    public double getConfidence() {
        return confidence;
    }

    public void setConfidence(double confidence) {
        this.confidence = confidence;
    }
}