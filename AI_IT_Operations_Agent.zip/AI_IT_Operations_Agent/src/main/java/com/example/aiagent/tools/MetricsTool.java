package com.example.aiagent.tools;

import com.example.aiagent.agent.ToolResult;

import org.springframework.stereotype.Component;

@Component
public class MetricsTool {

    public ToolResult execute() {

        String result = """
                System Metrics:

                cpuUsagePercent = 92
                memoryUsagePercent = 87
                diskUsagePercent = 76
                threadCount = 184
                """;

        return new ToolResult(
                "check_metrics",
                result
        );
    }
}