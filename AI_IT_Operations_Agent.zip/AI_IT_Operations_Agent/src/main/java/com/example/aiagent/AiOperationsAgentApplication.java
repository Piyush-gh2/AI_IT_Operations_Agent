package com.example.aiagent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AiOperationsAgentApplication {

    public static void main(String[] args) {

        SpringApplication.run(
                AiOperationsAgentApplication.class,
                args
        );
    }
}