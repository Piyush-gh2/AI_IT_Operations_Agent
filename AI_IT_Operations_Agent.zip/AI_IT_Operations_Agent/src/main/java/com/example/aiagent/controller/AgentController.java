package com.example.aiagent.controller;

import com.example.aiagent.dto.AgentRequest;
import com.example.aiagent.dto.AgentResponse;
import com.example.aiagent.service.AgentOrchestrator;

import jakarta.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/agent")
public class AgentController {

    private final AgentOrchestrator agentOrchestrator;

    public AgentController(
            AgentOrchestrator agentOrchestrator) {

        this.agentOrchestrator = agentOrchestrator;
    }

    @PostMapping("/investigate")
    public ResponseEntity<AgentResponse> investigate(
            @Valid @RequestBody AgentRequest request) {

        AgentResponse response =
                agentOrchestrator.investigate(
                        request.getIncident()
                );

        return ResponseEntity.ok(response);
    }
}