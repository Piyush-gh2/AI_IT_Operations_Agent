package com.example.aiagent.agent;

public class ToolResult {

    private final String toolName;
    private final String result;

    public ToolResult(
            String toolName,
            String result) {

        this.toolName = toolName;
        this.result = result;
    }

    public String getToolName() {
        return toolName;
    }

    public String getResult() {
        return result;
    }
}