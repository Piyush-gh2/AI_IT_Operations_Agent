package com.example.aiagent.tools;

import com.example.aiagent.agent.ToolResult;

import org.springframework.stereotype.Component;

@Component
public class LogAnalysisTool {

    public ToolResult execute(
            String input) {

        String result = """
                Application Log Analysis:

                ERROR: Request timeout after 5000ms

                WARN: Database connection pool
                near capacity

                ERROR:
                java.net.SocketTimeoutException

                INFO:
                Retry attempt triggered
                """;

        return new ToolResult(
                "analyze_logs",
                result
        );
    }
}