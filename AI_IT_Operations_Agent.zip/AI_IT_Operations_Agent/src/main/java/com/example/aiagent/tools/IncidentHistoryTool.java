package com.example.aiagent.tools;

import com.example.aiagent.agent.ToolResult;

import org.springframework.stereotype.Component;

@Component
public class IncidentHistoryTool {

    public ToolResult execute(
            String input) {

        String text =
                input == null
                        ? ""
                        : input.toLowerCase();

        String result;

        if (text.contains("slow")
                || text.contains("timeout")
                || text.contains("performance")
                || text.contains("latency")) {

            result = """
                    Historical Incident Match:

                    Title:
                    Slow Application Response

                    Category:
                    Performance

                    Priority:
                    P2

                    Possible Causes:
                    High CPU usage, memory pressure,
                    database latency, thread exhaustion,
                    or network latency.

                    Resolution:
                    Check CPU and memory.
                    Review application logs.
                    Check database response time.
                    Inspect thread usage.
                    """;

        } else if (text.contains("login")
                || text.contains("authentication")
                || text.contains("password")) {

            result = """
                    Historical Incident Match:

                    Title:
                    Login Failure

                    Category:
                    Authentication

                    Priority:
                    P2

                    Possible Causes:
                    Authentication service failure,
                    expired credentials, identity provider
                    issue, or configuration error.

                    Resolution:
                    Check authentication service
                    and identity provider logs.
                    """;

        } else if (text.contains("database")
                || text.contains("db")
                || text.contains("connection")) {

            result = """
                    Historical Incident Match:

                    Title:
                    Database Connection Failure

                    Category:
                    Database

                    Priority:
                    P1

                    Possible Causes:
                    Database outage, connection pool
                    exhaustion, network issue, or
                    invalid database configuration.

                    Resolution:
                    Check database health.
                    Check connection pool.
                    Verify network connectivity.
                    Check application configuration.
                    """;

        } else {

            result = """
                    Historical Incident Match:

                    Title:
                    Application Server Down

                    Category:
                    Application Service

                    Priority:
                    P1

                    Possible Causes:
                    Server crash, JVM failure,
                    memory exhaustion, configuration
                    error, or network connectivity issue.

                    Resolution:
                    Check application logs.
                    Check CPU and memory.
                    Check JVM usage.
                    Verify configuration.
                    Verify network connectivity.
                    """;
        }

        return new ToolResult(
                "search_incident_history",
                result
        );
    }
}