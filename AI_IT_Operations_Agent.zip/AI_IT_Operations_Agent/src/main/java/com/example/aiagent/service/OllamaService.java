package com.example.aiagent.service;

import com.example.aiagent.dto.AgentDecision;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import java.util.Map;

@Service
public class OllamaService {

    private final RestClient restClient;
    private final ObjectMapper objectMapper;

    public OllamaService(
            ObjectMapper objectMapper) {

        this.restClient = RestClient.builder()
                .baseUrl(
                        "http://host.docker.internal:11434"
                )
                .build();

        this.objectMapper = objectMapper;
    }

    public AgentDecision decide(
            String incident,
            String observations) {

        String prompt = """
                You are an autonomous IT Operations Agent.

                Your job is to investigate an IT incident
                using diagnostic tools.

                You must decide which tool should be used next.

                AVAILABLE TOOLS:

                1. check_health
                   Checks application/service health.

                2. check_metrics
                   Checks CPU, memory, disk and thread metrics.

                3. analyze_logs
                   Analyzes application logs for errors,
                   exceptions and timeouts.

                4. search_incident_history
                   Searches historical incidents for similar
                   problems.

                ==============================
                RULES
                ==============================

                - Select one tool at a time.
                - Use the observations already collected.
                - Do not invent tool results.
                - Do not execute dangerous actions.
                - Continue investigation when more evidence
                  is required.
                - Set done=true only when enough evidence
                  has been collected.
                - Severity must be one of:
                  LOW, MEDIUM, HIGH, CRITICAL.

                Return ONLY valid JSON.

                Required JSON format:

                {
                  "action": "check_health",
                  "input": "",
                  "done": false,
                  "severity": "HIGH",
                  "finalAnswer": ""
                }

                If the investigation is complete:

                {
                  "action": "",
                  "input": "",
                  "done": true,
                  "severity": "HIGH",
                  "finalAnswer": "Final investigation result"
                }

                ==============================
                INCIDENT
                ==============================

                %s

                ==============================
                OBSERVATIONS
                ==============================

                %s
                """.formatted(
                incident,
                observations
        );

        Map<String, Object> requestBody =
                Map.of(
                        "model", "llama3.2",
                        "prompt", prompt,
                        "stream", false,
                        "format", "json"
                );

        Map<String, Object> response =
                restClient.post()
                        .uri("/api/generate")
                        .contentType(
                                MediaType.APPLICATION_JSON
                        )
                        .body(requestBody)
                        .retrieve()
                        .body(Map.class);

        if (response == null
                || response.get("response") == null) {

            throw new IllegalStateException(
                    "Ollama did not return a response"
            );
        }

        String responseText =
                response.get("response").toString();

        System.out.println();
        System.out.println(
                "========== AGENT LLM DECISION =========="
        );

        System.out.println(responseText);

        System.out.println(
                "========================================="
        );

        try {

            return objectMapper.readValue(
                    responseText,
                    AgentDecision.class
            );

        } catch (Exception e) {

            throw new RuntimeException(
                    "Unable to parse Ollama agent decision: "
                            + responseText,
                    e
            );
        }
    }
}