package com.example.aiagent.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class AgentRequest {

    @NotBlank(message = "Incident is required")
    @Size(
            max = 5000,
            message = "Incident must not exceed 5000 characters"
    )
    private String incident;

    public AgentRequest() {
    }

    public AgentRequest(String incident) {
        this.incident = incident;
    }

    public String getIncident() {
        return incident;
    }

    public void setIncident(String incident) {
        this.incident = incident;
    }
}