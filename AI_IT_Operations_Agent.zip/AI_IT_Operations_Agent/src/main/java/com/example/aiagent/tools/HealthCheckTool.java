package com.example.aiagent.tools;

import com.example.aiagent.agent.ToolResult;

import org.springframework.stereotype.Component;

@Component
public class HealthCheckTool {

    public ToolResult execute() {

        String result = """
                Service Health Result:

                payment-service = UP
                order-service = UP
                user-service = UP

                responseTimeMs = 5200

                healthStatus = DEGRADED
                """;

        return new ToolResult(
                "check_health",
                result
        );
    }
}