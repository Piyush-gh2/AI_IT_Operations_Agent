package com.example.aiagent.service;

import com.example.aiagent.agent.ToolResult;
import com.example.aiagent.dto.AgentDecision;
import com.example.aiagent.dto.AgentResponse;
import com.example.aiagent.tools.HealthCheckTool;
import com.example.aiagent.tools.IncidentHistoryTool;
import com.example.aiagent.tools.LogAnalysisTool;
import com.example.aiagent.tools.MetricsTool;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class AgentOrchestrator {

    private static final int MAX_STEPS = 6;

    private final OllamaService ollamaService;
    private final HealthCheckTool healthCheckTool;
    private final MetricsTool metricsTool;
    private final LogAnalysisTool logAnalysisTool;
    private final IncidentHistoryTool incidentHistoryTool;

    public AgentOrchestrator(
            OllamaService ollamaService,
            HealthCheckTool healthCheckTool,
            MetricsTool metricsTool,
            LogAnalysisTool logAnalysisTool,
            IncidentHistoryTool incidentHistoryTool) {

        this.ollamaService = ollamaService;
        this.healthCheckTool = healthCheckTool;
        this.metricsTool = metricsTool;
        this.logAnalysisTool = logAnalysisTool;
        this.incidentHistoryTool = incidentHistoryTool;
    }

    public AgentResponse investigate(
            String incident) {

        List<String> actionsPerformed =
                new ArrayList<>();

        List<String> findings =
                new ArrayList<>();

        StringBuilder observations =
                new StringBuilder();

        String severity = "MEDIUM";

        String finalAnswer =
                "Investigation completed.";

        for (int step = 1;
             step <= MAX_STEPS;
             step++) {

            System.out.println();

            System.out.println(
                    "========== AGENT STEP "
                            + step
                            + " =========="
            );

            AgentDecision decision =
                    ollamaService.decide(
                            incident,
                            observations.toString()
                    );

            if (decision.getSeverity() != null
                    && !decision.getSeverity()
                    .isBlank()) {

                severity =
                        decision.getSeverity();
            }

            System.out.println(
                    "Selected Tool: "
                            + decision.getAction()
            );

            if (decision.isDone()) {

                finalAnswer =
                        decision.getFinalAnswer();

                if (finalAnswer == null
                        || finalAnswer.isBlank()) {

                    finalAnswer =
                            "Investigation completed.";
                }

                break;
            }

            ToolResult toolResult =
                    executeTool(
                            decision.getAction(),
                            decision.getInput(),
                            incident
                    );

            actionsPerformed.add(
                    toolResult.getToolName()
            );

            observations
                    .append("\n")
                    .append(
                            "========== "
                                    + toolResult
                                    .getToolName()
                                    + " ==========\n"
                    )
                    .append(
                            toolResult.getResult()
                    )
                    .append("\n");

            findings.add(
                    summarizeFinding(
                            toolResult.getToolName(),
                            toolResult.getResult()
                    )
            );

            System.out.println(
                    "Tool Result:"
            );

            System.out.println(
                    toolResult.getResult()
            );
        }

        return new AgentResponse(
                "INVESTIGATED",
                severity,
                extractRootCause(
                        observations.toString()
                ),
                finalAnswer,
                actionsPerformed,
                findings,
                calculateConfidence(
                        actionsPerformed.size()
                )
        );
    }

    private ToolResult executeTool(
            String action,
            String input,
            String incident) {

        if (action == null) {

            return new ToolResult(
                    "invalid_tool",
                    "No tool was selected."
            );
        }

        return switch (action) {

            case "check_health" ->
                    healthCheckTool.execute();

            case "check_metrics" ->
                    metricsTool.execute();

            case "analyze_logs" ->
                    logAnalysisTool.execute(
                            input
                    );

            case "search_incident_history" ->
                    incidentHistoryTool.execute(
                            incident
                    );

            default ->
                    new ToolResult(
                            "invalid_tool",
                            "Unknown tool: "
                                    + action
                    );
        };
    }

    private String summarizeFinding(
            String toolName,
            String result) {

        return switch (toolName) {

            case "check_health" ->
                    "Application health was checked. Services are available but response time is degraded.";

            case "check_metrics" ->
                    "System metrics show elevated CPU and memory utilization.";

            case "analyze_logs" ->
                    "Application logs contain request timeouts and database connection pool pressure.";

            case "search_incident_history" ->
                    "Historical incident knowledge was searched for a similar problem.";

            default ->
                    result;
        };
    }

    private String extractRootCause(
            String observations) {

        if (observations.contains(
                "cpuUsagePercent = 92")
                && observations.contains(
                "memoryUsagePercent = 87")) {

            return
                    "High system resource utilization is contributing to application performance degradation.";
        }

        if (observations.contains(
                "SocketTimeoutException")) {

            return
                    "Request timeouts are present in the application logs and may be contributing to the incident.";
        }

        return
                "The available diagnostic evidence indicates an application performance or service-level issue.";
    }

    private double calculateConfidence(
            int actionCount) {

        if (actionCount >= 4) {
            return 0.90;
        }

        if (actionCount == 3) {
            return 0.85;
        }

        if (actionCount == 2) {
            return 0.75;
        }

        return 0.65;
    }
}